void testStaging();
void test_Staging_Off(void);
void test_Staging_4cyl_Auto_Inactive(void);
void test_Staging_4cyl_Table_Inactive(void);
void test_Staging_4cyl_Auto_50pct(void);
void test_Staging_4cyl_Auto_33pct(void);
void test_Staging_4cyl_Table_50pct(void);
