# fp64lib

![logo](https://user-images.githubusercontent.com/54156171/162820277-988f4a62-45e3-4508-8f06-f271fc0a1b1a.png)

Handcrafted 64-bit floating point routines for AVR/arduino microprocessors, giving 15-17 digits of accuracy instead of the standard 6-7 digits.

See http://fp64lib.org for documentation and details
