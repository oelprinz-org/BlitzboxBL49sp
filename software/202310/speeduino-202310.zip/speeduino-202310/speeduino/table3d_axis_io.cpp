#include "table3d_axis_io.h"

constexpr int16_byte table3d_axis_io::converter_100;
constexpr int16_byte table3d_axis_io::converter_2;
constexpr int16_byte table3d_axis_io::converter_1;