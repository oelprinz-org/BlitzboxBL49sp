#include <stdlib.h>
#include "table3d_axes.h"

constexpr int16_ref::scalar table3d_axis_base::scalar_100;
constexpr int16_ref::scalar table3d_axis_base::scalar_2;
constexpr int16_ref::scalar table3d_axis_base::scalar_1;