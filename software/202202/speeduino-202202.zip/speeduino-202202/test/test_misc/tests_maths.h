extern void testMaths();
void test_maths_percent_U8(void);
void test_maths_percent_U16(void);
void test_maths_percent_U32(void);
void test_maths_halfpercent_U8(void);
void test_maths_halfpercent_U16(void);
void test_maths_halfpercent_U32(void);
void test_maths_div100_U8(void);
void test_maths_div100_U16(void);
void test_maths_div100_U32(void);
void test_maths_div100_S8(void);
void test_maths_div100_S16(void);
void test_maths_div100_S32(void);
void test_maths_div10_U8(void);
void test_maths_div10_U16(void);
void test_maths_div10_U32(void);


